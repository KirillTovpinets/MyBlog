<?php
$modx->hpCount = true;
return '';