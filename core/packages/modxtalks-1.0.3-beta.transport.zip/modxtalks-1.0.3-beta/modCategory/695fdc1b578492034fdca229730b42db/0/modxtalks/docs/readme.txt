--------------------
Extra: MODXTalks
--------------------
Version: 1.0.3 beta
Since: January, 2013
Author: Valentin Rasulov <info@artdevue.com> && Ivan Brezhnev <brezhnev.ivan@yahoo.com>

MODXTalsk flexible extension of voting for MODX Revolution. This component allows you to install a fully AJAX commenting system on any webpage.

See the documentation here: http://modxtalks.artdevue.com/en/help.html
The source code: http://github.com/artdevue/modxTalks
Issues: http://github.com/artdevue/modxTalks/issues