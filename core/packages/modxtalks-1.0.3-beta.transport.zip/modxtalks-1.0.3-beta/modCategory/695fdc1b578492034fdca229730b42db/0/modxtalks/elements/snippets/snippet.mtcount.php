<?php
$modx->mt_mtCount = true;
return '';