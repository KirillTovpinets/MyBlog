<?php
class modxTalksEmailBlock extends xPDOSimpleObject {}