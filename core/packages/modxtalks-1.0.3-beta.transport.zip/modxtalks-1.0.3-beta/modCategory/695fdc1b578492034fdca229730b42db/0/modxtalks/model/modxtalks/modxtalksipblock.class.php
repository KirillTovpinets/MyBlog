<?php
class modxTalksIpBlock extends xPDOSimpleObject {}