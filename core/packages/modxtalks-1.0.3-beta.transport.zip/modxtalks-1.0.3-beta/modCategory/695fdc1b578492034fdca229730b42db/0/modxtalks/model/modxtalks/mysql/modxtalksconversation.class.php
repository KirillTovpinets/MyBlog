<?php
require_once (dirname(dirname(__FILE__)) . '/modxtalksconversation.class.php');
class modxTalksConversation_mysql extends modxTalksConversation {
}