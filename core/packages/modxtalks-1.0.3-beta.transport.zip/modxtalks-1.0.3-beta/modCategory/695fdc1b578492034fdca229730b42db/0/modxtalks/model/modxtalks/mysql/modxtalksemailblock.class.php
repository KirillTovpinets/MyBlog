<?php
require_once (dirname(dirname(__FILE__)) . '/modxtalksemailblock.class.php');
class modxTalksEmailBlock_mysql extends modxTalksEmailBlock {}