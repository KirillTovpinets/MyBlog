<?php
require_once (dirname(dirname(__FILE__)) . '/modxtalksipblock.class.php');
class modxTalksIpBlock_mysql extends modxTalksIpBlock {}