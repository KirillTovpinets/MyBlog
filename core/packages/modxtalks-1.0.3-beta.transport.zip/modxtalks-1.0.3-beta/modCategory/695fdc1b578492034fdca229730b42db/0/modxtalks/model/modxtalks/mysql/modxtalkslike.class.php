<?php
require_once (dirname(dirname(__FILE__)) . '/modxtalkslike.class.php');
class modxTalksLike_mysql extends modxTalksLike {}