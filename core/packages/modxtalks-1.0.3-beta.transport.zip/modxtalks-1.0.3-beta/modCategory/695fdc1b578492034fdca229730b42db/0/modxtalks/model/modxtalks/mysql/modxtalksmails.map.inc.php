<?php
$xpdo_meta_map['modxTalksMails']= array (
  'package' => 'modxTalks',
  'version' => '1.1',
  'table' => 'modxtalks_mails',
  'extends' => 'xPDOSimpleObject',
  'fields' =>
  array (
    'post_id' => 0,
  ),
  'fieldMeta' =>
  array (
    'post_id' =>
    array (
      'dbtype' => 'int',
      'precision' => '11',
      'phptype' => 'integer',
      'null' => false,
    ),
  ),
);
