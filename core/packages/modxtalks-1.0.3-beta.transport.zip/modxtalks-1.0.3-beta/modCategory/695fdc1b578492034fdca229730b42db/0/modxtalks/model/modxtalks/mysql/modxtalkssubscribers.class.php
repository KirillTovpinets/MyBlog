<?php
require_once (dirname(dirname(__FILE__)) . '/modxtalkssubscribers.class.php');
class modxTalksSubscribers_mysql extends modxTalksSubscribers {}