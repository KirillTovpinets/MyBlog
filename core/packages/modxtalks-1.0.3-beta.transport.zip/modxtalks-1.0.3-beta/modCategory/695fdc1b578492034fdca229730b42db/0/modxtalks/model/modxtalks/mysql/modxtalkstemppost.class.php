<?php
require_once (dirname(dirname(__FILE__)) . '/modxtalkstemppost.class.php');
class modxTalksTempPost_mysql extends modxTalksTempPost {}