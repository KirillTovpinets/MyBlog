<?php
/**
 * Remove unconfirmed post
 *
 * @package modxtalks
 * @subpackage processors
 */